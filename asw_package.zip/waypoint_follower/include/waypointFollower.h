#ifndef WAYPOINTFOLLOWER_H
#define WAYPOINTFOLLOWER_H

#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <waypoint_maker/Lane.h>
#include <waypoint_maker/Waypoint.h>
#include <waypoint_maker/State.h>
#include <nav_msgs/Odometry.h>
#include <std_msgs/Bool.h>
#include <std_msgs/Int32.h>
#include <geometry_msgs/Pose2D.h>
#include <geometry_msgs/Twist.h>

#include <std_msgs/Float32.h>
#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <math.h>
#include <numeric>

#include <sensor_msgs/Imu.h>
//#include <morai_msgs/CtrlCmd.h>
//#include <morai_msgs/CollisionData.h>
//#include <morai_msgs/EgoVehicleStatus.h>
#include <tf/tf.h>
#include "ros/time.h"

//시간차 코드 헤더 파일
#include <chrono>
#include <thread>
#include <iostream>

#include <string> //문자열 출력
#include "asw_msgs/AswMsg.h"

//#include <traffic_light/gostop.h>

//service
//#include <morai_msgs/MoraiEventCmdSrv.h>
//#include <morai_msgs/EventInfo.h>
//#include <morai_msgs/Lamps.h>

#define INTER_TIME_PLUS 1000000000
#define INTER_TIME_MIN 90000000
#define INTER_TIME_MAX 200000000
#define INTER_SPEED_TIME_MAX 3600000000


using namespace std;

class WaypointFollower 
{
private:
	


//jinsung flag&count
    bool stop_flag = false;
    bool resume_flag = false;
    bool process_flag = false;
    ros::Time start_time;
    int count_turtle1 = 0;
	int count_turtle2 = 0;
	int count_turtle3 = 0;
	int count_turtle4 = 0;
	int count_jet1 = 0;
	int count_jet2 = 0;
	double count_time = 0.0;
	bool accel_flag = false;
    //jinsung flag&count

	
	bool lane_change_flag = false; //주차 때 정지했을 때 lanechange를 위한 코드

	
	bool static_flag = false;// for Jeong Min

	const double WHEEL_BASE = 0.15;
	const double MAX_SEARCH_DIST = 3.0;
	const double MAX_SUM = 58.0;
	const double MIN_SUM = -150.0;

	const double KI = 0.09; //0.09
	const double PID_FIT = 1.0;

	const double STRAGHT_LD = 0.4;//영상 나온거 0.6//0.4가 속도 0.5에서 잘 감
	const double CURVE_LD = 0.3;
	const double BIG_CURVE_LD = 3.0;
	const double PARKING_LD = 2.0;

	//-----------------ASW FLAG-----------------| hyeokk
	std::chrono::steady_clock::time_point parking_start_time1;
	std::chrono::steady_clock::time_point parking_start_time2;
	bool stoponce_flag = false;  //정지 일회성 코드를 위한 flag hyeokk
	bool parking_in_progress1 = false;  // 피팅으로 주차하는 경우 대비
	bool parking_in_progress2 = false;
	int parking_step = 1;
	int control_type;

	int waypoints_size_;
	int target_index_;
	
	vector<waypoint_maker::Waypoint> waypoints_;
	
	double dist_;
	double stop_dist_; //jinsung

	int current_mission_state_;
	int loader_number_;

	int waypoint_min_;
	int closest_waypoint_;

	int spd_state_;

	bool is_pose_;
	bool is_course_;
	bool is_lane_;
	bool is_control_;
	bool is_obs_detect_;
	bool vision_check_;
	double is_alpha;

	geometry_msgs::PoseStamped cur_pose_;
	
	double lookahead_dist_;
	double cur_course_;
	double cur_speed_; //speed over ground -> nmea sentence GPRMC 7
	
	ros::NodeHandle nh_;
	ros::NodeHandle private_nh_;
	
	
	ros::Publisher lane_number_pub_;
	ros::Publisher turtlebot_pub_; //터틀봇 과제
	ros::Publisher jetracer_pub_;  //jetracer cmd_vel publisher

	ros::Subscriber odom_sub_;
	ros::Subscriber lane_sub_;
	ros::Subscriber vision_sub_;
	ros::Subscriber state_sub_;
	ros::Subscriber imu_sub_;

	// ros::Subscriber line_sub_;
	ros::Subscriber vertical_sub_;
	ros::Subscriber obst_sub_;

	ros::Subscriber static_sub_;
	ros::Subscriber static_steer_;

	//------------ASW Mission Subscriber------------| 
    ros::Subscriber lidar_track1_sub_;
    ros::Subscriber lidar_track2_sub_;
    ros::Subscriber lidar_track3_sub_;
    ros::Subscriber lidar_track4_sub_;
    ros::Subscriber lidar_track5_sub_;

    ros::Subscriber taffic_sign_sub_;
    ros::Subscriber lane_steer_sub_;
	//-----------------------------------------------|

	
	//morai_msgs::CtrlCmd ackermann_msg_;
	waypoint_maker::State lane_number_msg_;
	vector<geometry_msgs::PoseStamped> traffic_stop_;
	geometry_msgs::Twist twist_msg_;

	ros::ServiceClient service_client_ ;//service
	//morai_msgs::MoraiEventCmdSrv srv_;
	
	//동적
	bool is_obs_detect_dy_;
	
	//굴절
	bool is_line_vertical_;
	//오르막
	bool is_hill_stop_done_;
	bool start_hill_stop_;

	bool is_first_stop_done_;
	bool start_first_stop_;
	bool nogps_steering_;
	
	bool is_third_stop_done_;
	bool start_third_stop_;
	bool nogps_steering_2_;

	//time fit
	double start_sec_;
	double during_sec_;
	bool gear_flag;
	double n_gps_start_sec_;
	double n_gps_during_sec_;
	double n_gps_start_sec2_;

	//service
    bool do_service_once_;
	
	double ex_x_, ex_y_;
    unsigned int ex_time_;
    int inter_time_;
    
    double sum_error_;
    double accel_, brake_;

	int parking_count_;
	bool is_backward_;
    
    bool is_dynamic_finished_;
	bool dynamic_check_flag_;


	bool is_vertical_;

	double parking_dist_;
	double filtered_yaw ;

	//----------------ASW SETTING----------------//
	bool static_flag_sudden = false;
	bool wait_flag = false;
	double lidar_linear_x_corn1;
	double lidar_angular_z_corn1;
	double lidar_linear_x_corn2;
	double lidar_angular_z_corn2;
	double lidar_linear_x_tunnel;
	double lidar_angular_z_tunnel;

	double cam_lane_steer;
	int traffic_sign;
	bool start_flag = false;

	double n_dist_ = 10.0;

	string cur_control;
	//--------------------------------------------//


	public:
	WaypointFollower() 
	{
		initSetup();
	}

	~WaypointFollower() 
	{
		waypoints_.clear();
	}
	
	double speed_;
	double cur_steer;
    double camera_angle_;
	double lidar_angle_;

	

	void initSetup() 
	{
	    ros::Time::init();
		
		lane_number_pub_ = nh_.advertise<waypoint_maker::State>("lane_number_msg_",1);
		jetracer_pub_ = nh_.advertise<geometry_msgs::Twist>("/cmd_vel",1);
		odom_sub_ = nh_.subscribe("odom", 1, &WaypointFollower::OdomCallback, this);

		lane_sub_ = nh_.subscribe("final_waypoints", 1, &WaypointFollower::LaneCallback, this);
		state_sub_ = nh_.subscribe("gps_state",1,&WaypointFollower::StateCallback,this);
		vision_sub_ = nh_.subscribe("/vision_check", 10, &WaypointFollower::TrafficSignCallback,this);
		imu_sub_ = nh_.subscribe("imu",1,&WaypointFollower::ImuCallback,this);
		static_sub_ = nh_.subscribe("/static_flag_topic",1,&WaypointFollower::StaticFlagCallback,this);
		// line_sub_ = nh_.subscribe("/lane_detector/camera_ackermann",1,&WaypointFollower::LineCallback,this);
		
		//----------ASW MISSION PUB SUB-------------//
    	lidar_track1_sub_ = nh_.subscribe("/lidar_corn2", 10, &WaypointFollower::track1Callback, this);
    	lidar_track2_sub_ = nh_.subscribe("/lidar_tunnel", 10, &WaypointFollower::track2Callback, this);
    	lidar_track4_sub_ = nh_.subscribe("lidar_obstacle2", 10, &WaypointFollower::track4Callback, this);
    	lidar_track5_sub_ = nh_.subscribe("lidar_corn1", 10, &WaypointFollower::track5Callback, this);

		taffic_sign_sub_ = nh_.subscribe("traffic_sign_flag", 10, &WaypointFollower::trafficsignCallback, this);
    	lane_steer_sub_ = nh_.subscribe("cam_steer", 10, &WaypointFollower::camsteerCallback, this);

		
		waypoints_size_ = 0;

		dist_ = 100.0;
		lookahead_dist_ = STRAGHT_LD;
		current_mission_state_ = -1;
		waypoint_min_ = -1;
		parking_count_ = -3;

		is_pose_ = false;
		is_course_ = false;
		is_lane_ = false;
		is_control_ = false;

		is_obs_detect_dy_ = false;	//동적

		//오르막
		is_hill_stop_done_ = false;
		start_hill_stop_ = false;

		//음영구역
		is_first_stop_done_ = false;
		start_first_stop_ = false;
		nogps_steering_ = false;
	
		is_third_stop_done_ = false;
		start_third_stop_ = false;
		nogps_steering_2_ = false;

		gear_flag = false;
		is_vertical_ = false;
		is_line_vertical_ = false;
/////////////////////////////vision

		vision_check_ = true;

		spd_state_ = 0;

		is_obs_detect_ = false;
		
		//service
   		do_service_once_ = false;
    	inter_time_ = 0;

		cur_course_ = .0;
		cur_speed_ = .0;
		loader_number_ = 0;
		ex_x_ = 0;
		ex_y_ = 0;
		ex_time_ = 0;
		sum_error_ = 0;
		n_gps_start_sec_ = .0;
		n_gps_during_sec_ = .0;
		n_gps_start_sec2_ = .0;

		is_backward_ = false;
		dynamic_check_flag_ = false;
		
		speed_ = .0;
		cur_steer = .0;
    	camera_angle_ = .0;
		lidar_angle_ = .0;

		accel_ = 0;
		brake_ = 0;
        nh_.getParam("/waypoint_follower_node/is_dynamic_finished", is_dynamic_finished_);
        nh_.getParam("/waypoint_follower_node/is_parking_dist", parking_dist_);
	}

	double calcPlaneDist(const geometry_msgs::PoseStamped pose1, const geometry_msgs::PoseStamped pose2) 
	{
		return sqrt(pow(pose1.pose.position.x - pose2.pose.position.x, 2) + pow(pose1.pose.position.y - pose2.pose.position.y, 2));
	}






	/* void CollisionCallback(const morai_msgs::CollisionData::ConstPtr& _collision_msg)
	{
		if(!_collision_msg->collision_object.empty())
		{
			for (auto i = 0; i < _collision_msg->collision_object.size(); i++)
				cout << "!!!!!!!!!!!!!!!!!!!!!!!" << _collision_msg->collision_object[i].name << endl;
		}
	} */
// for Jeong Min
	void StaticFlagCallback(const std_msgs::Bool::ConstPtr& msg){
		static_flag = msg->data;
	}


	void OdomCallback(const nav_msgs::Odometry::ConstPtr &odom_msg) 
	{
		cur_pose_.header = odom_msg->header;
		cur_pose_.pose.position = odom_msg->pose.pose.position;
	    inter_time_ = cur_pose_.header.stamp.nsec - ex_time_;
        if(inter_time_ <= 0) inter_time_ += INTER_TIME_PLUS; 
        
	    ex_time_ = cur_pose_.header.stamp.nsec;
	    ex_x_ = cur_pose_.pose.position.x;
        ex_y_ = cur_pose_.pose.position.y;
		is_pose_ = true;
		// cout<<"is_pose_"<<is_pose_<<endl;
		tf::Quaternion q(odom_msg->pose.pose.orientation.x, odom_msg->pose.pose.orientation.y,
			odom_msg->pose.pose.orientation.z, odom_msg->pose.pose.orientation.w);
		tf::Matrix3x3 m(q);
		double roll, pitch, yaw;
		m.getRPY(roll,pitch,yaw);
		filtered_yaw = yaw;

	}

	void LaneCallback(const waypoint_maker::Lane::ConstPtr &lane_msg) 
	{
		waypoints_.clear();
		vector<waypoint_maker::Waypoint>().swap(waypoints_);
		waypoints_ = lane_msg->waypoints;
		waypoints_size_ = waypoints_.size();
		if (waypoints_size_ != 0) is_lane_ = true;
	}

	void TrafficSignCallback(const std_msgs::Bool::ConstPtr& vision_msg)
	{
		vision_check_ = vision_msg->data;
	}
	
	void StateCallback(const waypoint_maker::State::ConstPtr &state_msg)
	{
		dist_ = state_msg->dist;
		current_mission_state_ = state_msg->current_state;
		loader_number_ = state_msg->lane_number;
		stop_dist_ = state_msg->n_s_dist;
		

	}
	


	
	void ImuCallback(const sensor_msgs::Imu::ConstPtr &imu_msg)
	{
		tf::Quaternion q(imu_msg->orientation.x, imu_msg->orientation.y,
			imu_msg->orientation.z, imu_msg->orientation.w);
		tf::Matrix3x3 m(q);
		double roll, pitch, yaw;
		m.getRPY(roll,pitch,yaw);
		cur_course_ = yaw;
		is_course_ = true;
	}

	//--------------ASW MISSION CALLBACK-------------//
    void track1Callback(const asw_msgs::AswMsg::ConstPtr &msg)
    {
		lidar_linear_x_corn1 = msg->lidar_linear_x;
		lidar_angular_z_corn1 = msg->lidar_angular_z;
    }

    void track2Callback(const asw_msgs::AswMsg::ConstPtr &msg)
    {
        lidar_linear_x_tunnel = msg->lidar_linear_x;
		lidar_angular_z_tunnel = msg->lidar_angular_z;
    }

    void track4Callback(const asw_msgs::AswMsg::ConstPtr &msg)
    {
        static_flag_sudden = msg->static_flag;
    }

    void track5Callback(const asw_msgs::AswMsg::ConstPtr &msg)
    {
        lidar_linear_x_corn2 = msg->lidar_linear_x;
		lidar_angular_z_corn2 = msg->lidar_angular_z;
    }

    void trafficsignCallback(const asw_msgs::AswMsg::ConstPtr &msg)
    {
        traffic_sign = msg->traffic_num;
    }

	void camsteerCallback(const asw_msgs::AswMsg::ConstPtr &msg)
    {
        cam_lane_steer = msg->cam_steer;
    }
	
	// void LineCallback(const ackermann_msgs::AckermannDriveStamped::ConstPtr &camera_msg)
	// {
	// 	camera_angle_ = camera_msg->drive.steering_angle * -(M_PI / 180.0) * 2;
	// }

	

	void getClosestWaypoint(geometry_msgs::PoseStamped current_pose) 
	{
		if (!waypoints_.empty()) 
		{
			double dist_min = MAX_SEARCH_DIST;
			for (int i = 0; i < waypoints_.size(); i++)
			{
				double dist = calcPlaneDist(current_pose, waypoints_[i].pose);
				if (dist < dist_min) 
				{
					dist_min = dist;
					waypoint_min_ = i;
				}
			}
			closest_waypoint_ = waypoint_min_;
		}
		else cout << "------ NO CLOSEST WAYPOINT -------" << endl;
	}
	
	
	
	double getSpeed(double& ex_x, double& ex_y, double cur_x, double cur_y)
	{
        double distance = sqrt(pow((cur_x - ex_x ), 2) + pow((cur_y - ex_y), 2));
        double speed = distance / inter_time_ * INTER_SPEED_TIME_MAX;
 
        // cout << "distance   :: " << distance << endl;
        // cout << "time   "  << inter_time_ <<  "    ::    speed  " << speed << endl;
        return speed;
	}
	
    double PID(double target, double cur_speed) 
	{
        if (target == 0) return 0;
        target = target - PID_FIT;
        double error = target - cur_speed;
        if (error < 0) sum_error_ = 0;
        
        sum_error_ += error;
        
        if (sum_error_ > MAX_SUM) sum_error_ = MAX_SUM;
        else if (sum_error_ < MIN_SUM) sum_error_ = MIN_SUM;
        
        double result = KI * sum_error_ + target;
        if (result >= 20.0) result = 20.0;
        
        return result;
    }


    

	void process();
	double calcAngularVelocity();
	double PurePursuit(double speed);
	double ReversePureJinsungPursuit(double speed);
	double ActiveLookaheaddist(double speed);
	int find_cloestindex(geometry_msgs::PoseStamped pose);

};

#endif
