#include <ros/ros.h>
#include <waypoint_maker/Lane.h>          // For Parking Mission
#include <waypoint_maker/Waypoint.h>      // Waypoints
#include <waypoint_maker/State.h>         // For Mission (미션에 필요한 msg 헤더 모음)
#include <std_msgs/Header.h>
#include <std_msgs/Bool.h>
#include <ros/time.h>
#include <iostream>

// For 자료형
#include <geometry_msgs/PoseStamped.h>
#include <nav_msgs/Odometry.h>
#include <std_msgs/Bool.h>
#include <vector>
#include <string>
#include <nav_msgs/Path.h>

#include <chrono>
#include <thread>

//asw_msgs 파일 선언
#include "asw_msgs/AswMsg.h"

// For CSV file loading
#include <fstream>
#include <sys/types.h>    // 시스템 자료형 타입 정리용 헤더
#include <dirent.h>       // 디렉토리 다루기 위한 헤더
#include <sstream>        // 문자열 스트림 처리

// 랜덤 장애물 회피 시간 할당 hyeokk
#include <chrono>
#include <thread>
#include <iostream>

using namespace std;
using namespace std::chrono;

class WaypointLoader
{
private:
    const double MAX_SEARCH_DIST = 20.0;
    const char* CSV_PATH = "/home/kuuve/catkin_ws/src/data/";

    ros::NodeHandle nh_;

    // Publisher
    ros::Publisher waypoint_pub_;
    ros::Publisher state_pub_;
    ros::Publisher rviz_global_path_;
    ros::Publisher past_path_pub_;


    // Subscriber
    ros::Subscriber pose_sub_;
    ros::Subscriber stopline_sub_;
    // ros::Subscriber static_sub_; //정적 장애물 sub

    // ASW Mission Subscriber
    ros::Subscriber lidar_track6_sub_;
    ros::Subscriber lidar_track3_sub_;
    ros::Publisher mission_state_pub_;

    // CSV Loading variables
    std::vector<std::string> all_csv_;
    vector<vector<waypoint_maker::Waypoint>> all_new_waypoints_;
    vector<waypoint_maker::Waypoint> new_waypoints_;
    vector<int> lane_size_; // Waypoints
    vector<vector<int>> all_state_index_;

    // 지나간 경로를 저장할 벡터
    vector<geometry_msgs::PoseStamped> past_path_;
    nav_msgs::Path past_path_rviz_;

    // State용 변수
    int state_inspection_;
    int current_mission_state_;

    // Final Waypoint
    vector<waypoint_maker::Waypoint> final_waypoints_;

    // 랜덤 장애물 회피 시간 할당 코드 hyeokk
	std::chrono::steady_clock::time_point lane_change_start_time;
	bool lane_change_in_progress = false;

    // Closest Waypoint용 변수들
    vector<int> closest_waypoint_candidates_;

    double dist_;
    int closest_waypoint_;

    // For Parking
    int parking_state_;
    int lane_number_;

    bool is_state_; // middle start4
    bool stopline_flag;
    // bool static_flag = false; //static_flag 선언 hyeokk

    //for lane change   
	int lane_change_ = 0;
	int mission_state_;
    bool right_flag = true;
    bool left_flag = false;

    //--------ASW FLAG--------------//
    bool static_flag_acrylic = false;
    bool static_flag_park = false;
    bool static_once_flag = false;
    int traffic_flag = 0;
    asw_msgs::AswMsg asw_msg;

    // msg들
    geometry_msgs::PoseStamped current_pose_; // 지역 변수 -> 전역 변수로 변경
    waypoint_maker::Lane lane_msg_;
    waypoint_maker::State state_msg_;

    int cur_lane_;

    int specific_index_ = 270; //지정한 인덱스부터 추종하도록 함 hyeokk

    // 기타 변수
    int final_size_;
    int size_;

public:
    WaypointLoader()
    {
        initSetup();
        ROS_INFO("WAYPOINT LOADER INITIALIZED.");
    }

    ~WaypointLoader()
    {
        new_waypoints_.clear();
        all_new_waypoints_.clear();
        final_waypoints_.clear();
        ROS_INFO("WAYPOINT LOADER TERMINATED.");
    }

    void initSetup()
    {
        nh_.getParam("/waypoint_loader_node/state_inspection", state_inspection_);
        nh_.getParam("/waypoint_loader_node/parking_count", parking_state_);

        final_size_ = 50;
        current_mission_state_ = state_inspection_;
        closest_waypoint_ = 0;

        lane_change_ = 0;

        is_state_ = false; // middle start

        getCSVFilesInDirectory();
        loadWaypointsFromCSV();

        rviz_global_path_ = nh_.advertise<nav_msgs::Path>("/rviz_global_path", 1);
        waypoint_pub_ = nh_.advertise<waypoint_maker::Lane>("final_waypoints", 1);
        state_pub_ = nh_.advertise<waypoint_maker::State>("gps_state", 1);
        past_path_pub_ = nh_.advertise<nav_msgs::Path>("/rviz_past_path", 1);
        pose_sub_ = nh_.subscribe("odom", 10, &WaypointLoader::poseCallback, this);
        stopline_sub_ = nh_.subscribe("/stop_flag", 10, &WaypointLoader::stoplineCallback, this);
        // static_sub_ = nh_.subscribe("/static_flag_topic",1,&WaypointLoader::StaticFlagCallback,this);  //static_sub 정의 hyeokk

        //----------ASW MISSION PUB SUB-------------//
        mission_state_pub_ = nh_.advertise<asw_msgs::AswMsg>("asw_state", 1);
        lidar_track3_sub_ = nh_.subscribe("lidar_obstacle3", 10, &WaypointLoader::track3Callback, this);
        lidar_track6_sub_ = nh_.subscribe("lidar_obstacle1", 10, &WaypointLoader::track6Callback, this);
    }

    void poseCallback(const nav_msgs::Odometry::ConstPtr& msg)
    {
        current_pose_.pose.position = msg->pose.pose.position;
        current_pose_.pose.orientation = msg->pose.pose.orientation;
        lane_msg_.header = msg->header;
    }

    // void StaticFlagCallback(const new_lane::lidar_setting::ConstPtr& msg){  // static_flag callback 함수 정의 hyeokk
	// 	static_flag = msg->flag;
	// }

    void lanechangeCallback(const waypoint_maker::State::ConstPtr &msg)
	{
		mission_state_ = msg->current_state;

	}

    void stoplineCallback(const std_msgs::Bool::ConstPtr &msg)
    {
        stopline_flag = msg -> data;
    }

    //--------------ASW MISSION CALLBACK-------------//
    void track6Callback(const asw_msgs::AswMsg::ConstPtr &msg)
    {
        static_flag_acrylic = msg->static_flag;
        traffic_flag = msg->traffic_num;
    }

    void track3Callback(const asw_msgs::AswMsg::ConstPtr &msg)
    {
        static_flag_park = msg->static_flag;
    }

    void process()
    {
        if (new_waypoints_.empty())
        {
            ROS_WARN("waypoint not loaded");
            return;
        }

        final_waypoints_.clear();

        if (mission_state_ == 11) 
            {
                parkingWaypoint();
            } 
        else 
            {
                getClosestWaypoint();   // 기존 방식으로 가장 가까운 경로점 추종
                if (closest_waypoint_ == -1) 
                    {
                    ROS_WARN("could not find closest waypoint");
                    return;
                    }
            }

        laneChange();
        getFinalWaypoints();
        updateMissionState();
        getStopVelocityDist();
        publishMessages();
    }

    // Functions
    void getCSVFilesInDirectory()
    {
        DIR* dirp = opendir(CSV_PATH);

        if (dirp == NULL)
        {
            perror("UNABLE TO OPEN FOLDER");
            return;
        }

        struct dirent* dp;
        while ((dp = readdir(dirp)) != NULL)
        {
            string filename(dp->d_name);

            if (filename.size() > 2)
            {
                string address(CSV_PATH);
                address.append(filename);
                all_csv_.emplace_back(address);
                ROS_INFO("CSV 파일 로드: %s", address.c_str());
            }
        }

        sort(all_csv_.begin(), all_csv_.end());
        closedir(dirp);
    }

    void loadWaypointsFromCSV()
    {
        for (const auto& csv_file : all_csv_)
        {
            ifstream is(csv_file);
            if (!is.is_open())
            {
                ROS_WARN("CSV 파일을 열 수 없습니다: %s", csv_file.c_str());
                continue;
            }

            ROS_INFO("CSV 파일 로드 중: %s", csv_file.c_str());

            vector<waypoint_maker::Waypoint> temp_waypoints;
            vector<int> state_indices;

            // 첫 번째 미션 상태의 인덱스를 0으로 설정
            state_indices.emplace_back(0);

            string line;
            int waypoint_index = 0;
            int prev_mission_state = -1;

            while (getline(is, line))
            {
                if (line.empty())
                    continue;

                stringstream ss(line);
                string cell;
                vector<string> data;

                while (getline(ss, cell, ','))
                {
                    data.push_back(cell);
                }

                if (data.size() < 4)
                {
                    ROS_WARN("bad csv format");
                    continue;
                }

                waypoint_maker::Waypoint wp;

                wp.waypoint_index = stoi(data[0]);
                wp.pose.pose.position.x = stod(data[1]);
                wp.pose.pose.position.y = stod(data[2]);
                wp.mission_state = stoi(data[3]);
                // wp.ryaw = stod(data[4]);
                // wp.rk = stod(data[5]);

                temp_waypoints.emplace_back(wp);

                if (prev_mission_state != wp.mission_state)
                {
                    state_indices.emplace_back(waypoint_index);
                    prev_mission_state = wp.mission_state;
                }

                waypoint_index++;
            }

            is.close();

            all_new_waypoints_.emplace_back(temp_waypoints);
            all_state_index_.emplace_back(state_indices);
            lane_size_.emplace_back(temp_waypoints.size());

            ROS_INFO("%lu waypoints loaded", temp_waypoints.size());
        }

        // 기본 차선 설정
        if (!all_new_waypoints_.empty())
        {
            new_waypoints_ = all_new_waypoints_[lane_change_];
            size_ = lane_size_[lane_change_];
        }
        else
        {
            ROS_WARN("waypoint not loaded.");
        }
    }

    //왼쪽 플래그 줄때만 레인체인지 하는거 생각, 우회전은 플래그 받을 필요 없을듯
    void laneChange()
    {

        // 아크릴 판 인식 후 lane_chage
        if (!static_once_flag)
        {
            if(current_mission_state_ == 1 && lane_change_ == 0 && static_flag_acrylic)
            {
                lane_change_ = 1;
			    new_waypoints_.clear();
			    new_waypoints_.assign(all_new_waypoints_[lane_change_].begin(), all_new_waypoints_[lane_change_].end());
			    size_ = lane_size_[lane_change_];

                if (static_flag_acrylic)
                {
                    static_once_flag = true;
                }

                cout << "LANE CHANGED TO 1.CSV" << endl;    
            }
        }

        if(current_mission_state_ == 3 && lane_change_ == 1)
        {
            lane_change_ = 0;
			new_waypoints_.clear();
			new_waypoints_.assign(all_new_waypoints_[lane_change_].begin(), all_new_waypoints_[lane_change_].end());
			size_ = lane_size_[lane_change_];
            cout << "LANE CHANGED TO 0.CSV" << endl;
        }


        //-----------------RANDOM OBSTACLE LANE CHANGE---------------------
        if(current_mission_state_ == 6 && lane_change_ == 0 && static_flag_park)
        {
            lane_change_ = 2;
			new_waypoints_.clear();
			new_waypoints_.assign(all_new_waypoints_[lane_change_].begin(), all_new_waypoints_[lane_change_].end());
			size_ = lane_size_[lane_change_];
            cout << "LANE CHANGED TO 2.CSV" << endl;
        }

        // RANDOM OBSTACLE FINISH
        if(current_mission_state_ == 7 && lane_change_ == 0)
        {
            lane_change_ = 2;
			new_waypoints_.clear();
			new_waypoints_.assign(all_new_waypoints_[lane_change_].begin(), all_new_waypoints_[lane_change_].end());
			size_ = lane_size_[lane_change_];
            cout << "LANE CHANGED TO 2.CSV" << endl;
        }
        //------------------------------RANDOM OBSTACLE FINISHED----------------------------

        // Parking
        if(current_mission_state_ == 11 && lane_change_ == 2)
        {
            lane_change_ = 3;
			new_waypoints_.clear();
			new_waypoints_.assign(all_new_waypoints_[lane_change_].begin(), all_new_waypoints_[lane_change_].end());
			size_ = lane_size_[lane_change_];
            cout << "LANE CHANGED TO 3.CSV" << endl;
        
        }

        if(current_mission_state_ == 12 && lane_change_ == 3)
        {
            lane_change_ = 4;
			new_waypoints_.clear();
			new_waypoints_.assign(all_new_waypoints_[lane_change_].begin(), all_new_waypoints_[lane_change_].end());
			size_ = lane_size_[lane_change_];
            cout << "LANE CHANGED TO 4.CSV" << endl;
        }

        if(current_mission_state_ == 18 && lane_change_ == 4 && traffic_flag == 1) //수정 필요
        {
            lane_change_ = 5;
			new_waypoints_.clear();
			new_waypoints_.assign(all_new_waypoints_[lane_change_].begin(), all_new_waypoints_[lane_change_].end());
			size_ = lane_size_[lane_change_];
            cout << "LANE CHANGED TO 5.CSV" << endl;
        
        }

    }


    void getClosestWaypoint()
    {
        closest_waypoint_candidates_.clear();
        closest_waypoint_ = -1;

        if (new_waypoints_.empty())
            return;

        int start_index = 0;

        // 현재 미션 상태의 시작 인덱스를 가져옴
        if (current_mission_state_ < all_state_index_[lane_change_].size())
        {
            start_index = all_state_index_[lane_change_][current_mission_state_];
        }

        // 인덱스가 벡터 범위를 벗어나지 않도록 보정
        if (start_index < 0)
            start_index = 0;
        if (start_index >= new_waypoints_.size())
            start_index = new_waypoints_.size() - 1;

        double min_dist = MAX_SEARCH_DIST;

        for (int i = start_index; i < new_waypoints_.size(); ++i)
        {
            double dist = calcPlaneDist(current_pose_, new_waypoints_[i].pose);

            if (dist < min_dist)
            {
                min_dist = dist;
                closest_waypoint_ = i;
            }

            if (dist > MAX_SEARCH_DIST)
                break;
        }

        if (closest_waypoint_ != -1)
        {
            asw_msg.mission_state_num = current_mission_state_;
            mission_state_pub_.publish(asw_msg);
			ROS_INFO("\n\n----------\n\nINDEX= %d\nX= %f\nY= %f\nmission_state= %d\ncurrent_lane = %d\n\n----------", closest_waypoint_, new_waypoints_[closest_waypoint_].pose.pose.position.x, new_waypoints_[closest_waypoint_].pose.pose.position.y, current_mission_state_, lane_change_);
			is_state_ = true;//middle start
        }
        else
        {
            is_state_ = false;
            ROS_WARN("could not find closest waypoint");
        }
    }

    void getFinalWaypoints()
    {
        final_waypoints_.clear();

        if (closest_waypoint_ == -1)
            return;

        int remaining_waypoints = size_ - closest_waypoint_;
        int final_waypoints_count = min(final_size_, remaining_waypoints);

        for (int i = 0; i < final_waypoints_count; ++i)
        {
            final_waypoints_.emplace_back(new_waypoints_[closest_waypoint_ + i]);
        }
    }

    void updateMissionState()
    {
        nh_.getParam("/waypoint_loader_node/parking_count", parking_state_);

        if (parking_state_ > -2)
            current_mission_state_ = parking_state_ + 19;
        else if (!final_waypoints_.empty())
            current_mission_state_ = final_waypoints_[0].mission_state;
        else
            current_mission_state_ = state_inspection_;

        int next_state_index = current_mission_state_ + 1;

        if (next_state_index < all_state_index_[lane_change_].size())
        {
            int waypoint_index = all_state_index_[lane_change_][next_state_index];
            if (waypoint_index < new_waypoints_.size())
            {
                dist_ = calcPlaneDist(current_pose_, new_waypoints_[waypoint_index].pose);
            }
            else
            {
                dist_ = 0.0;
            }
        }
        else
        {
            dist_ = 0.0;
        }

        state_msg_.dist = dist_;
        state_msg_.current_state = current_mission_state_;
        state_msg_.header.stamp = ros::Time::now();
    }
    void getStopVelocityDist() { //정지선에서 멈추기 전에 감속, 다시 출발하기 전에 부드러운 가속을 하기 위해 필요 거리를 구하는 함수(process로 넘어감)
        state_msg_.n_s_dist = calcPlaneDist(current_pose_, new_waypoints_[all_state_index_[lane_change_][current_mission_state_ + 2]].pose);
        cout << "n_dist : " << state_msg_.n_s_dist << endl;
        
    }

    void publishMessages()
    {
        // 상태 메시지 발행
        state_pub_.publish(state_msg_);

        // 웨이포인트 메시지 발행
        lane_msg_.waypoints = final_waypoints_;
        waypoint_pub_.publish(lane_msg_);

        // 지나간 경로를 RViz에 게시
        past_path_.emplace_back(current_pose_);

        past_path_rviz_.header.frame_id = "odom";
        past_path_rviz_.header.stamp = ros::Time::now();
        past_path_rviz_.poses = past_path_;
        past_path_pub_.publish(past_path_rviz_);
    }

    void publishGlobalPath()
    {
        nav_msgs::Path global_path_rviz;
        global_path_rviz.header.frame_id = "odom";
        global_path_rviz.header.stamp = ros::Time::now();

        for (const auto& waypoints : all_new_waypoints_)
        {
            for (const auto& wp : waypoints)
            {
                geometry_msgs::PoseStamped pose;
                pose.header.frame_id = "odom";
                pose.header.stamp = ros::Time::now();
                pose.pose.position.x = wp.pose.pose.position.x;
                pose.pose.position.y = wp.pose.pose.position.y;
                pose.pose.position.z = 0.0;

                global_path_rviz.poses.emplace_back(pose);
            }
        }

        rviz_global_path_.publish(global_path_rviz);
    }

    void parkingWaypoint()  //지정한 인덱스부터 추종하는 함수
    {
    if (specific_index_ < 0 || specific_index_ >= new_waypoints_.size()) 
        {
        ROS_WARN("Invalid waypoint index.");
        return;
        }

    // 지정된 인덱스의 경로점을 추종
    closest_waypoint_ = specific_index_;
    ROS_INFO("Following waypoint at index: %d", closest_waypoint_);
    }

    double calcPlaneDist(const geometry_msgs::PoseStamped& pose1, const geometry_msgs::PoseStamped& pose2)
    {
        return sqrt(pow(pose1.pose.position.x - pose2.pose.position.x, 2) +
                    pow(pose1.pose.position.y - pose2.pose.position.y, 2));
    }

		void loader_rviz()
	{
		//1. 경로 총갯수 파악
		int total_size = 0;
		nav_msgs::Path global_path_rviz;
		global_path_rviz.header.frame_id = "odom";
		global_path_rviz.header.stamp = ros::Time::now();
		for(int i =0; i< all_csv_.size();i++)
		{
			total_size+=all_new_waypoints_[i].size();
		}
		// global_path_rviz.poses.resize(total_size);
		if(all_csv_.size()!=0)
		{
			int idx_rowsize = 0;
			for (int i = 0; i < all_csv_.size(); i++)
			{
				for(int j=0;j<all_new_waypoints_[i].size();j++)
				{
					geometry_msgs::PoseStamped loc;
					loc.header.frame_id = "odom";
					loc.header.stamp = ros::Time::now();
					loc.pose.position.x = (double)all_new_waypoints_[i][j].pose.pose.position.x;
					loc.pose.position.y = (double)all_new_waypoints_[i][j].pose.pose.position.y;
					// cout << "loc.pose.position.x" << (double)loc.pose.position.x << endl;
					// cout << "all new waypoints[i][j] : " << (double)all_new_waypoints_[i][j].pose.pose.position.x<<endl;
					// ROS_INFO("loc x : %lf",loc.pose.position.x);
					// ROS_INFO("loc y : %lf",loc.pose.position.y);
					loc.pose.position.z = 0.0;
					if(j % 10 == 0){
						global_path_rviz.poses.emplace_back(loc);
					}
				}
					idx_rowsize += all_new_waypoints_[i].size();
			}
		}	
		for(int i =0; i< all_csv_.size();i++)
		{
			total_size+=all_new_waypoints_[i].size();
		}
		rviz_global_path_.publish(global_path_rviz);
	}  
    
};

int main(int argc, char** argv)
{
    ros::init(argc, argv, "waypoint_loader");
    WaypointLoader wl;
    ros::Rate loop_rate(10); // 10Hz

    while (ros::ok())
    {
        ros::spinOnce();
        wl.process();
        wl.publishGlobalPath();
        loop_rate.sleep();
    }
    return 0;
}
