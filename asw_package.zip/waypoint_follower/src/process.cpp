#include <ros/ros.h>
#include <waypointFollower.h>

void WaypointFollower::process() 
{
	if(is_pose_ && is_lane_)
	{ 
		is_control_ = true;

		switch(current_mission_state_)
		{	
			// 출발선 - 아크릴 인식 전까지 구간 직진
			case 0:
				control_type = 0; 
				speed_ = 0.5;
				lookahead_dist_ = STRAGHT_LD;
				break;
					
			//아크릴 인지- 정지선 정지상태
			case 1:
				control_type = 1;
				if (!stoponce_flag)
        		{
           		speed_ = 0.0;
				cur_steer = 0.0;
				lookahead_dist_ = STRAGHT_LD;

				twist_msg_.angular.z = cur_steer;
            	twist_msg_.linear.x = speed_;

				jetracer_pub_.publish(twist_msg_);
            	
				stoponce_flag = true;
				cur_control = "STOPLINE 2 SECONDS";
				ros::Duration(2.0).sleep();  // 이 시간동안 앞에 아크릴 인지
				}
				else
				{
				speed_ = 0.5;
				lookahead_dist_ = STRAGHT_LD;
				cur_steer = PurePursuit(speed_);

				twist_msg_.angular.z = cur_steer;
            	twist_msg_.linear.x = speed_;

				jetracer_pub_.publish(twist_msg_);
				}
				break;

            //아크릴 인지 후 주행 - (로터리 - odom의 정확성을 위해 현재 csv를 유지)
			case 2:
				control_type = 0;
				stoponce_flag = true;
				speed_ = 0.5;
				lookahead_dist_ = STRAGHT_LD;
				break;

			// S자 구간 - 돌발 장애물
			case 3:
				control_type = 0;
				if (static_flag_sudden)
				{
					speed_ = 0.0;
					lookahead_dist_ = STRAGHT_LD;
				}
				else
				{
					speed_ = 0.5;
					lookahead_dist_ = STRAGHT_LD;
				}
				break;

			// S자 직진 후 커브 코스 - 정지선 감속
			case 4:
				control_type = 1;
				if (!stoponce_flag)
        		{
           		speed_ = 0.0;
				cur_steer = 0.0;
				lookahead_dist_ = STRAGHT_LD;

				twist_msg_.angular.z = cur_steer;
            	twist_msg_.linear.x = speed_;

				jetracer_pub_.publish(twist_msg_);
            	
				stoponce_flag = true;
				cur_control = "STOPLINE";
				ros::Duration(1.5).sleep();
				}
				else
				{			
				speed_ = 0.5;
				cur_steer = PurePursuit(speed_);
				lookahead_dist_ = STRAGHT_LD;
				
				twist_msg_.angular.z = cur_steer;
            	twist_msg_.linear.x = speed_;

				jetracer_pub_.publish(twist_msg_);
				cur_control = "GO";
				}
				break;

            // 정지선 정지 후 출발 - 헤딩 정면 될 때까지    
			case 5:
				control_type = 0;
				stoponce_flag = false;
				speed_ = 0.5;
				lookahead_dist_ = STRAGHT_LD;
				cur_control = "HEADING STRAGHT";
				break;

			// 랜덤 장애물 구간 + lane change (waypoint_loader)
			case 6:
				control_type = 0;
				speed_ = 0.5;
				lookahead_dist_ = STRAGHT_LD;  // LD값을 증가하여 오실 감소
				cur_control = "RANDON OBSTACLE";
				break;
			
			// 랜덤 장애물 중앙차선으로 이동
			case 7:
				control_type = 0;
				speed_ = 0.5;
				lookahead_dist_ = STRAGHT_LD;
				cur_control = "RANDOM OBSTACLE Finish";
				break;

			// 라바콘 주행 - lidar 구간 or Odometry
			case 8:
				control_type = 0;
                speed_ = 0.5;
				lookahead_dist_ = STRAGHT_LD;
				cur_control = "S CORN COURSE";
				break;

			// case 9:
			// 	speed_ = 0.2;
			// 	cur_steer = lidar_angular_z_corn1;  //Lidar 기반 주행
			// 	break;
			
			// 정지선에서 정지 후 주행
			case 9:
				control_type = 1;
				if (!stoponce_flag)
        		{
           		speed_ = 0.0;
				cur_steer = 0.0;
				lookahead_dist_ = STRAGHT_LD;

				twist_msg_.angular.z = cur_steer;
            	twist_msg_.linear.x = speed_;

				jetracer_pub_.publish(twist_msg_);
            	
				stoponce_flag = true;
				cout << "STOP FOR 1 SECOND" << endl;
				ros::Duration(1.0).sleep();
				}
				else
				{
				// speed_ = Acceleration(speed_, 0.5, 1);
				speed_ = 0.5;
				cur_steer = PurePursuit(speed_);
				lookahead_dist_ = STRAGHT_LD;

				twist_msg_.angular.z = cur_steer;
            	twist_msg_.linear.x = speed_;

				jetracer_pub_.publish(twist_msg_);
				}
				break;
			
			// 정지선 전까지 주행
			case 10:
				control_type = 0;
				stoponce_flag = false;
				speed_ = 0.5;
				lookahead_dist_ = STRAGHT_LD;
				cur_control = "GO";
				break;

			// 후진 전 정지 -> lane change
			case 11:
				control_type = 1;
				if (!stoponce_flag)
        		{
           		speed_ = 0.0;
				cur_steer = 0.0;
				lookahead_dist_ = STRAGHT_LD;
				
				twist_msg_.angular.z = cur_steer;
            	twist_msg_.linear.x = speed_;

				jetracer_pub_.publish(twist_msg_);
            	
				stoponce_flag = true;
				cur_control = "!!READY TO PARK";
				ros::Duration(1.0).sleep();
				}
				else
				{
				speed_ = -0.5;
				lookahead_dist_ = STRAGHT_LD;
				cur_steer = ReversePureJinsungPursuit(speed_);

				twist_msg_.angular.z = cur_steer;
            	twist_msg_.linear.x = speed_;

				jetracer_pub_.publish(twist_msg_);
				
				cur_control = "!!PARING!!";
				}
				break;

			// 주차 후진하고 정지 주차 finish
			case 12:
				control_type = 1;
				stoponce_flag = false;
				speed_ = -0.5;
				lookahead_dist_ = STRAGHT_LD;
				cur_steer = ReversePureJinsungPursuit(speed_);

				twist_msg_.angular.z = cur_steer;
            	twist_msg_.linear.x = speed_;

				jetracer_pub_.publish(twist_msg_);
				
				cur_control = "!!PARING!!";

				break;
			
			// 주차 완료 lane change하고 주행
			case 13:
				control_type = 1;
				if (!stoponce_flag)
        		{
           		speed_ = 0.0;
				cur_steer = 0.0;
				lookahead_dist_ = STRAGHT_LD;

				twist_msg_.angular.z = cur_steer;
            	twist_msg_.linear.x = speed_;

				jetracer_pub_.publish(twist_msg_);
            	
				stoponce_flag = true;
				cout << "STOP FOR 1 SECOND" << endl;
				ros::Duration(1.0).sleep();
				}
				else
				{
				// speed_ = Acceleration(speed_, 0.5, 1);
				speed_ = 0.5;
				lookahead_dist_ = STRAGHT_LD;
				cur_steer = PurePursuit(speed_);
				
				twist_msg_.angular.z = cur_steer;
            	twist_msg_.linear.x = speed_;

				jetracer_pub_.publish(twist_msg_);
				}

				break;

			/*case 8:
				if (parking_in_progress1) {
        			auto now = steady_clock::now();
        			duration<double> elapsed = now - parking_start_time1;

        			if (elapsed.count() < 2.0) {
            			// 2초가 지나지 않으면 현재 주행 상태 유지--------->> !! 시간은 후진하는 시간 할 것 !!
            			return;
        			} 
					else {
            			// 2초가 지나면
            			parking_in_progress1 = false;
						parking_step = 2;
        			}
    			}

				if (parking_in_progress2) {
        			auto now = steady_clock::now();
        			duration<double> elapsed = now - parking_start_time2;

        			if (elapsed.count() < 2.0) {
            			// 2초가 지나지 않으면 현재 주행 상태 유지--------->> !! 시간은 후진하는 시간 할 것 !!
            			return;
        			} 
					else {
            			// 2초가 지나면
            			parking_in_progress2 = false;
						parking_step = 3;
        			}
    			}

				if (parking_step == 1)
				{
					speed_ = -0.1;
					cur_steer = -0.xxxx;

					parking_start_time1 = steady_clock::now();
            		parking_in_progress2 = true;
				}

				if (parking_step == 2)
				{
					speed_ = -0.1
					cur_steer = 0;

					parking_start_time2 = steady_clock::now();
            		parking_in_progress2 = true;
				}
				break;
				
			*/

			// 주차 완료 후 정지선까지 주행
			case 14:
				control_type = 0;
				stoponce_flag = false;
				speed_ = 0.5;
				lookahead_dist_ = STRAGHT_LD;
				break;

			// 정지선에서 정지
			case 15:
				control_type = 1;
				if (!stoponce_flag)
        		{
           		speed_ = 0.0;
				lookahead_dist_ = STRAGHT_LD;

				cur_steer = PurePursuit(speed_);
				twist_msg_.angular.z = cur_steer;
            	twist_msg_.linear.x = speed_;

				jetracer_pub_.publish(twist_msg_);
            	
				stoponce_flag = true;
				cout << "STOP FOR 1 SECOND" << endl;
				ros::Duration(1.0).sleep();
				}
				else
				{
				// speed_ = Acceleration(speed_, 0.5, 1);
				speed_ = 0.5;
				lookahead_dist_ = STRAGHT_LD;
				}

				break;

			// 신호등까지 주행
			case 16:
				control_type = 0;
				stoponce_flag = false;
				speed_ = 0.5;
                lookahead_dist_ = STRAGHT_LD;
				cur_control = "GO UNTIL TRAFFIC MISSION";
				break;

			// 터널 구간 - Odometry or Lidar
			// case 16:
			// 	speed_ = 0.2;
            //     lookahead_dist_ = STRAGHT_LD;
			// 	cur_control = "TUNNEL";
			// 	break;

			/*
			case 16:
				speed_ = -0.2;
                cur_steer = lidar_angular_z_tunnel;
				break;
			*/
            
			// 신호등 전 정지 및 신호등 판단
			case 17:
				control_type = 0;
				if (!stoponce_flag)
				{
					speed_ = 0;
					cur_steer = 0;
					twist_msg_.linear.x = speed_;
					twist_msg_.angular.z = cur_steer;
					jetracer_pub_.publish(twist_msg_);
					stoponce_flag = true;
					cout << "==== STOP FOR 2 SECONDS =====" << endl;
					ros::Duration(2.0).sleep();
				}
				else
				{
					if (traffic_sign == 0)  //Stop sign
					{
						speed_ = 0;
						cur_steer = 0;
						cur_control = "STOP SIGN";
					}
					else if (traffic_sign == 1)  //Left
					{
						speed_ = 0.2;
						lookahead_dist_ = STRAGHT_LD;
						cur_control = "LEFT SIGN";
					}
					else if (traffic_sign == 2)  //Right
					{
						speed_ = 0.2;
						lookahead_dist_ = STRAGHT_LD;
						cur_control = "RIGHT SIGN";
					}
					else
					{
						speed_ = 0;
						cur_steer = 0;
						lookahead_dist_ = STRAGHT_LD;
						cur_control = "??TRAFFIC SIGN??";
					}
				}

				break;

			// 주차 - lane change
			case 18:
				control_type = 0;
				speed_ = 0.5;
				lookahead_dist_ = STRAGHT_LD;
				cur_control = "FINAL PARKING";
				break;

			case 19:
				control_type = 0;
				speed_ = 0;
				cur_steer = 0;
				cur_control = "C O M P L E T E";
				break;




        }
	
	if (is_control_) 
	{ 
		if (control_type == 0)
		{
			cur_steer = PurePursuit(speed_);
			twist_msg_.linear.x = speed_;
			twist_msg_.angular.z = cur_steer;
			jetracer_pub_.publish(twist_msg_);
		}
		else if (control_type == 1)
		{
		}
		

	}

	is_pose_ = false;
	is_course_ = false;

	// cout << "===== PROCESS ====="<< endl;
	// cout << "Mission : " << cur_control << endl;
	// cout << "current_mission_state_ : " << current_mission_state_ << endl;
    // cout << "speed : " << twist_msg_.linear.x << endl;
	// cout << "steer : " << twist_msg_.angular.z <<endl;
    // cout << "LD : " << lookahead_dist_ <<endl;
	ROS_INFO("\n\n===== PROCESS =====\n\nMission: %s\ncurrent_mission_state_: %d\nspeed: %f\nsteer: %f\nLD : %f", 
	cur_control.c_str(), current_mission_state_, twist_msg_.linear.x, twist_msg_.angular.z, lookahead_dist_);
	}
}
