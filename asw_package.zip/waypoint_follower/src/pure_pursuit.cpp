#include <ros/ros.h>
#include <waypointFollower.h>

double WaypointFollower::PurePursuit(double speed) 
{
    // double k = 1.5;
    // lookahead_dist_ = k * speed; 
    // double kappa;
    // lookahead_dist_, kappa = ActiveLookaheaddist(speed);
    // cout << kappa << endl;
    // int min_index = find_cloestindex(cur_pose_);
    for(int i = 0; i < waypoints_size_; i++) 
    {
        // cout << "waypoint_size= " << waypoints_size_ << endl;
        double dist = calcPlaneDist(cur_pose_, waypoints_[i].pose);
        // cout << "dist" << dist << endl;
        if(dist > lookahead_dist_)
        {
            target_index_ = i;
            break;
        }
    }
    double cur_x = cur_pose_.pose.position.x;
    double cur_y = cur_pose_.pose.position.y;
    double heading = filtered_yaw;

    double cur_x_rear = cur_x; - (WHEEL_BASE / 2 * cos(heading));
    double cur_y_rear = cur_y; - (WHEEL_BASE / 2 * sin(heading));

    // cout << "cur_pose= " << cur_pose_.pose.position << endl;

    double t_x = waypoints_[target_index_].pose.pose.position.x;
    double t_y = waypoints_[target_index_].pose.pose.position.y;

    // cout << "wapoint= " << waypoints_[target_index_].pose.pose.position << endl;
    // cout << "target= " << target_index_ << endl;

    double dx = t_x - cur_x_rear;
    double dy = t_y - cur_y_rear;

    double x_local = cos(-heading) * dx - sin(-heading) * dy;
    double y_local = sin(-heading) * dx + cos(-heading) * dy;

    double alpha = atan2(y_local, x_local);

    double lookahead_dist = sqrt(x_local * x_local + y_local * y_local);
    double kappa = (2 * sin(alpha)) / lookahead_dist;

    double gain = 1.0;
    double delta = atan(gain * kappa * WHEEL_BASE);
    if (delta < -0.34) {
        delta = -0.34;
    }
    else if (delta > 0.34) {
        delta = 0.34;
    }
    double angular_velocity = speed * tan(delta) / WHEEL_BASE;

    // double turning_radius = lookahead_dist_ / (2 * sin(alpha));

    // double angular_velocity = speed / turning_radius;


    // double rk;
    // rk = waypoints_[min_index].rk;

    // cout<<"rk----->"<<rk;


    // if(rk > 0.09)
    // {
    //     delta = 1.25*delta;
    // }

    return delta;

}


double WaypointFollower::ReversePureJinsungPursuit(double speed)
{
    // getClosestWaypoint(cur_pose_);
   
    double k = 2.5;
    lookahead_dist_ = k * abs(speed);
    for(int i = 0; i < waypoints_size_; i++)
    {
        // cout << "waypoint_size= " << waypoints_size_ << endl;
        double dist = calcPlaneDist(cur_pose_, waypoints_[i].pose);
        // cout << "dist" << dist << endl;
        if(dist > lookahead_dist_)
        {
            target_index_ = i;
            
            break;
        }
    }
    double cur_x = cur_pose_.pose.position.x;
    double cur_y = cur_pose_.pose.position.y;
    double heading = filtered_yaw + M_PI;

    double cur_x_rear = cur_x - (WHEEL_BASE / 2 * cos(heading));
    double cur_y_rear = cur_y - (WHEEL_BASE / 2 * sin(heading));

    // cout << "cur_pose= " << cur_pose_.pose.position << endl;
    double t_x = waypoints_[target_index_].pose.pose.position.x;
    double t_y = waypoints_[target_index_].pose.pose.position.y;
    // cout << "wapoint= " << waypoints_[target_index_].pose.pose.position << endl;
    // cout << "target= " << target_index_ << endl;
    double dx = t_x - cur_x_rear;
    double dy = t_y - cur_y_rear;
    double x_local = cos(-heading) * dx - sin(-heading) * dy;
    double y_local = sin(-heading) * dx + cos(-heading) * dy;
    double alpha = atan2(y_local, x_local);
    double beta = M_PI - alpha;
    double lookahead_dist = sqrt(x_local * x_local + y_local * y_local);
    double kappa = (2 * sin(beta)) / lookahead_dist;
    double gain = 1.3;
    double delta = atan(gain * kappa * WHEEL_BASE);
    double angular_velocity = speed * tan(delta) / WHEEL_BASE;
    // delta인지 angular_velocity인지 확인하기
    if (angular_velocity < -0.34) {
        angular_velocity = -0.34;
    }
    else if (angular_velocity > 0.34) {
        angular_velocity = 0.34;
    }
    return angular_velocity;
}

double WaypointFollower::ActiveLookaheaddist(double speed) {
    double k = 2.5;
    double a = 2.0;
    for(int i = 0; i < waypoints_size_; i++) 
    {
        // cout << "waypoint_size= " << waypoints_size_ << endl;
        double dist = calcPlaneDist(cur_pose_, waypoints_[i].pose);
        // cout << "dist" << dist << endl;
        if(dist > lookahead_dist_)
        {
            target_index_ = i;
            break;
        }
    }
    double cur_x = cur_pose_.pose.position.x;
    double cur_y = cur_pose_.pose.position.y;
    double heading = filtered_yaw;

    // cout << "cur_pose= " << cur_pose_.pose.position << endl;

    double t_x = waypoints_[target_index_].pose.pose.position.x;
    double t_y = waypoints_[target_index_].pose.pose.position.y;

    // cout << "wapoint= " << waypoints_[target_index_].pose.pose.position << endl;
    // cout << "target= " << target_index_ << endl;

    double dx = t_x - cur_x;
    double dy = t_y - cur_y;

    double x_local = cos(-heading) * dx - sin(-heading) * dy;
    double y_local = sin(-heading) * dx + cos(-heading) * dy;

    double alpha = atan2(y_local, x_local);

    double lookahead_dist = sqrt(x_local * x_local + y_local * y_local);
    double kappa = (2 * sin(alpha)) / lookahead_dist;
    double active_lookahead_dist = (k * speed) /(a * abs(kappa));

    return active_lookahead_dist, kappa;

}

int WaypointFollower::find_cloestindex(geometry_msgs::PoseStamped pose)  // 이때 pose 는 내 위치에서 앞바퀴 축으로 회전변환 시켜서 사용해야함
{
    double min_dis = 0.0;
    int min_idx = 0;
    for(int i=0;i < waypoints_size_;i++)
    {
        double dist = calcPlaneDist(pose,waypoints_[i].pose);
        if(dist < min_dis)
        {
            min_dis = dist;
            min_idx = i;
        }
    }
    return min_idx;
}